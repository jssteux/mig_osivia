@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.xmlsoap.org/ws/2004/08/eventing")
package org.jboss.ws.extensions.eventing.jaxws;
